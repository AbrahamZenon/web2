<?php
// Lấy danh sách tất cả các danh mục từ DB để làm menu
$cat_sql = "SELECT id, name FROM categories";
$cat_stmt = $conn->prepare($cat_sql);
$cat_stmt->execute();
$categories = $cat_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cửa hàng Máy tính</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4; }
        header { background: #333; color: #fff; padding: 15px 20px; display: flex; gap: 20px; align-items: center; }
        header a { color: #fff; text-decoration: none; font-weight: bold; padding: 5px 10px; border-radius: 4px; }
        header a:hover { background: #555; }
        .container { max-width: 1200px; margin: 20px auto; padding: 0 15px; }
        .product-grid { display: flex; flex-wrap: wrap; gap: 20px; }
        .product-card { background: #fff; padding: 15px; width: calc(25% - 20px); border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); display: flex; flex-direction: column; }
        .price { color: #e74c3c; font-weight: bold; font-size: 1.2em; margin-top: auto; padding-top: 10px; }
        .badge { background: #eee; padding: 3px 8px; border-radius: 12px; font-size: 0.8em; color: #333; display: inline-block; margin-bottom: 5px; }
        .btn { display: block; text-align: center; background: #3498db; color: #fff; padding: 8px 15px; text-decoration: none; border-radius: 4px; margin-top: 10px; }
        .btn:hover { background: #2980b9; }
    </style>
</head>
<body>

<header>
    <a href="index.php" style="color: #f39c12; font-size: 1.2em;">ACER STORE</a>
    <a href="index.php">Tất cả sản phẩm</a>
    
    <!-- Vòng lặp in ra các danh mục -->
    <?php foreach($categories as $cat): ?>
        <a href="index.php?category_id=<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></a>
    <?php endforeach; ?>

    <!-- Nút sang trang Admin được đẩy sang lề phải -->
    <a href="admin.php" style="background: #c0392b; padding: 5px 15px; border-radius: 20px; margin-left: auto;">⚙️ Quản lý Admin</a>
</header>

<div class="container">