</div> <!-- Đóng thẻ .container -->
<footer style="text-align: center; padding: 20px; background: #333; color: #fff; margin-top: 40px;">
    &copy; <?php echo date("Y"); ?> Bản quyền thuộc về Nhóm của bạn.
</footer>
</body>
</html>