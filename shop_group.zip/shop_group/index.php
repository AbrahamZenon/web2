<?php
require_once 'config/database.php';

// Kiểm tra xem trên URL có truyền category_id xuống không
$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : 0;

// Câu SQL mặc định (lấy tất cả sản phẩm)
$sql = "
    SELECT p.id, p.name, p.specs, p.price, p.image_url, 
           c.name AS category_name, b.name AS brand_name
    FROM products p
    INNER JOIN categories c ON p.category_id = c.id
    INNER JOIN brands b ON p.brand_id = b.id
    WHERE p.visible = 1
";

// Nếu người dùng có bấm lọc danh mục, nối thêm điều kiện WHERE
if ($category_id > 0) {
    $sql .= " AND p.category_id = :category_id ";
    $page_title = "Sản phẩm theo danh mục";
} else {
    $page_title = "Tất cả sản phẩm";
}

$sql .= " ORDER BY p.id DESC";

$stmt = $conn->prepare($sql);

// Truyền giá trị an toàn vào SQL nếu có lọc
if ($category_id > 0) {
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
}

$stmt->execute();
$products = $stmt->fetchAll();

// Gọi phần Header (Nó sẽ tự động in menu các danh mục)
require_once 'includes/header.php';
?>

<h2><?= $page_title ?></h2>

<div class="product-grid">
    <?php if(count($products) > 0): ?>
        <?php foreach($products as $product): ?>
            <div class="product-card">
                <img src="<?= $product['image_url'] ?? 'https://via.placeholder.com/250x150?text=No+Image' ?>" alt="<?= htmlspecialchars($product['name']) ?>" style="width: 100%; border-radius: 4px;">
                
                <h3 style="font-size: 1.1em;"><?= htmlspecialchars($product['name']) ?></h3>
                
                <div>
                    <span class="badge"><?= htmlspecialchars($product['brand_name']) ?></span>
                    <span class="badge"><?= htmlspecialchars($product['category_name']) ?></span>
                </div>
                
                <p style="font-size: 0.9em; color: #666;"><?= htmlspecialchars($product['specs']) ?></p>
                
                <p class="price"><?= number_format($product['price'], 0, ',', '.') ?> đ</p>
                
                <a href="product.php?id=<?= $product['id'] ?>" class="btn">Xem chi tiết</a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="color: red; font-size: 1.2em;">Không có sản phẩm nào trong danh mục này.</p>
    <?php endif; ?>
</div>

<?php
require_once 'includes/footer.php';
?>