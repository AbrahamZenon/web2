<?php
require_once 'config/database.php';

// XỬ LÝ XÓA SẢN PHẨM: Nếu trên URL có biến ?delete_id=...
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    // Xóa khỏi DB
    $stmt = $conn->prepare("DELETE FROM products WHERE id = :id");
    $stmt->bindParam(':id', $delete_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Xóa xong thì load lại trang để cập nhật danh sách
    header("Location: admin.php");
    exit;
}

// Lấy danh sách toàn bộ sản phẩm (kể cả bị ẩn) để Admin quản lý
$sql = "
    SELECT p.id, p.name, p.price, p.visible, c.name AS category_name 
    FROM products p
    INNER JOIN categories c ON p.category_id = c.id
    ORDER BY p.id DESC
";
$stmt = $conn->query($sql);
$products = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<div style="background: white; padding: 20px; border-radius: 8px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Quản lý Sản phẩm</h2>
        <a href="admin_edit.php" style="background: #27ae60; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;">+ Thêm sản phẩm mới</a>
    </div>

    <table border="1" width="100%" cellspacing="0" cellpadding="10" style="border-collapse: collapse; text-align: left;">
        <tr style="background: #f4f4f4;">
            <th>ID</th>
            <th>Tên sản phẩm</th>
            <th>Danh mục</th>
            <th>Giá</th>
            <th>Hành động</th>
        </tr>
        
        <?php foreach($products as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
            <td><?= htmlspecialchars($p['category_name']) ?></td>
            <td style="color: red;"><?= number_format($p['price'], 0, ',', '.') ?> đ</td>
            <td>
                <!-- Nút Sửa trỏ đến trang admin_edit.php kèm theo ID -->
                <a href="admin_edit.php?id=<?= $p['id'] ?>" style="color: blue; text-decoration: none; margin-right: 10px;">✏️ Sửa</a>
                
                <!-- Nút Xóa có cảnh báo JavaScript -->
                <a href="admin.php?delete_id=<?= $p['id'] ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này không?');" style="color: red; text-decoration: none;">🗑️ Xóa</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php require_once 'includes/footer.php'; ?>