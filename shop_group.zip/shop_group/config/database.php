<?php
// config/database.php

$host     = "localhost";
$dbname   = "ShopGroupDB";
$username = "root"; // Tài khoản mặc định của XAMPP
$password = "";     // Mật khẩu mặc định của XAMPP

try {
    // Kết nối bằng PDO
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Lỗi kết nối CSDL: " . $e->getMessage());
}
?>