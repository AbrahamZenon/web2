<?php
require_once 'config/database.php';

// Kiểm tra xem là Đang Sửa (có ID) hay Thêm Mới (không có ID)
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$is_edit = ($id > 0);

// Lấy danh sách danh mục để in ra thẻ <select>
$stmt = $conn->query("SELECT id, name FROM categories WHERE brand_id = 1");
$categories = $stmt->fetchAll();

// Khởi tạo các biến rỗng cho Form (dành cho Thêm mới)
$name = $specs = $description = $image_url = "";
$price = 0;
$category_id = 0;

// Nếu là Sửa, lấy dữ liệu cũ từ DB đổ vào biến
if ($is_edit) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $product = $stmt->fetch();
    
    if ($product) {
        $name = $product['name'];
        $specs = $product['specs'];
        $description = $product['description'];
        $price = $product['price'];
        $image_url = $product['image_url'];
        $category_id = $product['category_id'];
    }
}

// XỬ LÝ KHI NGƯỜI DÙNG BẤM NÚT "LƯU"
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $category_id = $_POST['category_id'];
    $price = $_POST['price'];
    $specs = $_POST['specs'];
    $image_url = $_POST['image_url'];
    $description = $_POST['description'];
    $brand_id = 1; // Mặc định là Acer (ID = 1)
    
    if ($is_edit) {
        // CÂU LỆNH UPDATE
        $sql = "UPDATE products SET category_id = ?, name = ?, specs = ?, description = ?, price = ?, image_url = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$category_id, $name, $specs, $description, $price, $image_url, $id]);
    } else {
        // CÂU LỆNH INSERT
        $sql = "INSERT INTO products (brand_id, category_id, name, specs, description, price, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$brand_id, $category_id, $name, $specs, $description, $price, $image_url]);
    }
    
    // Lưu xong quay về trang danh sách
    header("Location: admin.php");
    exit;
}

require_once 'includes/header.php';
?>

<div style="background: white; padding: 20px; border-radius: 8px; max-width: 600px; margin: auto;">
    <h2><?= $is_edit ? "Sửa sản phẩm" : "Thêm sản phẩm mới" ?></h2>
    
    <!-- Form gửi dữ liệu bằng phương thức POST -->
    <form method="POST" action="">
        <div style="margin-bottom: 15px;">
            <label>Tên sản phẩm:</label><br>
            <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required style="width: 100%; padding: 8px;">
        </div>
        
        <div style="margin-bottom: 15px;">
            <label>Danh mục:</label><br>
            <select name="category_id" style="width: 100%; padding: 8px;">
                <?php foreach($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= ($category_id == $cat['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label>Giá bán (VNĐ):</label><br>
            <input type="number" name="price" value="<?= $price ?>" required style="width: 100%; padding: 8px;">
        </div>
        
        <div style="margin-bottom: 15px;">
            <label>Thông số tóm tắt (Specs):</label><br>
            <input type="text" name="specs" value="<?= htmlspecialchars($specs) ?>" style="width: 100%; padding: 8px;">
        </div>
        
        <div style="margin-bottom: 15px;">
            <label>Link ảnh (URL):</label><br>
            <input type="text" name="image_url" value="<?= htmlspecialchars($image_url) ?>" style="width: 100%; padding: 8px;" placeholder="https://...">
        </div>
        
        <div style="margin-bottom: 15px;">
            <label>Mô tả chi tiết:</label><br>
            <textarea name="description" rows="5" style="width: 100%; padding: 8px;"><?= htmlspecialchars($description) ?></textarea>
        </div>
        
        <button type="submit" style="background: #3498db; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 1.1em;">
            💾 Lưu Sản Phẩm
        </button>
        <a href="admin.php" style="margin-left: 15px; color: #666;">Hủy bỏ</a>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>