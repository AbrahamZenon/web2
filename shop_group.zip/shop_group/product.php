<?php
// Gọi file kết nối database
require_once 'config/database.php';

// Lấy ID sản phẩm từ thanh địa chỉ (URL)
// Nếu không có id trên URL, mặc định gán bằng 0
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($product_id === 0) {
    die("<h2>Đường dẫn không hợp lệ. Vui lòng quay lại trang chủ.</h2>");
}

// Lấy thông tin chi tiết của sản phẩm dựa vào ID
$sql = "
    SELECT p.*, c.name AS category_name, b.name AS brand_name
    FROM products p
    INNER JOIN categories c ON p.category_id = c.id
    INNER JOIN brands b ON p.brand_id = b.id
    WHERE p.id = :id AND p.visible = 1
";
$stmt = $conn->prepare($sql);
// Truyền giá trị ID vào câu SQL (cách này giúp chống SQL Injection an toàn tuyệt đối)
$stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
$stmt->execute();
$product = $stmt->fetch();

// Kiểm tra xem sản phẩm có tồn tại không
if (!$product) {
    die("<h2>Không tìm thấy sản phẩm hoặc sản phẩm đã bị ngừng kinh doanh.</h2>");
}

// Gọi phần Header
require_once 'includes/header.php';
?>

<style>
    /* CSS dành riêng cho trang chi tiết */
    .product-detail { display: flex; gap: 30px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
    .product-image { flex: 1; }
    .product-image img { width: 100%; border-radius: 8px; border: 1px solid #eee; }
    .product-info { flex: 1; }
    .product-price { color: #e74c3c; font-size: 2em; font-weight: bold; margin: 15px 0; }
    .btn-buy { background: #27ae60; color: white; padding: 12px 25px; border: none; font-size: 1.1em; border-radius: 5px; cursor: pointer; }
    .btn-buy:hover { background: #2ecc71; }
    .description { margin-top: 30px; background: #fff; padding: 20px; border-radius: 8px; }
</style>

<!-- Hiển thị nội dung sản phẩm -->
<div class="product-detail">
    <div class="product-image">
        <img src="<?= $product['image_url'] ?? 'https://via.placeholder.com/600x400?text=No+Image' ?>" alt="<?= htmlspecialchars($product['name']) ?>">
    </div>
    
    <div class="product-info">
        <h1><?= htmlspecialchars($product['name']) ?></h1>
        <p>
            <span class="badge"><?= htmlspecialchars($product['brand_name']) ?></span>
            <span class="badge"><?= htmlspecialchars($product['category_name']) ?></span>
        </p>
        
        <div class="product-price"><?= number_format($product['price'], 0, ',', '.') ?> VNĐ</div>
        
        <h3>Thông số kỹ thuật:</h3>
        <p><?= htmlspecialchars($product['specs']) ?></p>
        
        <button class="btn-buy">Thêm vào giỏ hàng</button>
    </div>
</div>

<!-- Phần mô tả chi tiết -->
<div class="description">
    <h3>Mô tả chi tiết:</h3>
    <p>
        <?php 
            // Nếu cột description trống, hiện câu thông báo mặc định
            echo !empty($product['description']) ? nl2br(htmlspecialchars($product['description'])) : 'Chưa có mô tả chi tiết cho sản phẩm này.';
        ?>
    </p>
</div>

<?php
// Gọi phần Footer
require_once 'includes/footer.php';
?>